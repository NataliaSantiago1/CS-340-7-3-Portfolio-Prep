from pymongo import MongoClient

class AnimalShelter:
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, connection_string="mongodb://aacuser:strongpassword@nv-desktop-services.apporto.com:32768/?directConnection=true&appName=mongosh+1.8.0"):
        print(f"Initializing with connection string: {connection_string}")
        self.client = MongoClient(connection_string)
        self.database = self.client['AAC']
        self.collection = self.database['animals']
        print('MongoDB connection successful')

    def create(self, data):
        if data:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"An error occurred: {e}")
                return False
        else:
            raise ValueError("Nothing to save, data parameter is empty")

    def read(self, search):
        try:
            results = self.collection.find(search)
            print(f'Read query results: {results}')  # Debug: Inspect query results
            return list(results)
        except Exception as e:
            print(f"An error occurred while reading from MongoDB: {e}")
            return []

    def update(self, search, data):
        try:
            result = self.collection.update_many(search, {'$set': data})
            return result.modified_count
        except Exception as e:
            print(f"An error occurred while updating MongoDB: {e}")
            return 0

    def delete(self, search):
        try:
            result = self.collection.delete_many(search)
            return result.deleted_count
        except Exception as e:
            print(f"An error occurred while deleting from MongoDB: {e}")
            return 0
